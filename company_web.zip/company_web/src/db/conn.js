const mongoose = require("mongoose");
mongoose.connect("mongodb://localhost:27017/issues_register",{
    useNewUrlParser:true,
    useUnifiedTopology:true,
    //useCreateIndex:true
}).then(()=>{
    console.log("connection sucess");
}).catch((e)=>{
    console.log(e);
})