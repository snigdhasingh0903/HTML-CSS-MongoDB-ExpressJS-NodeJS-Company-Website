const express=require("express");
const path =require("path");
const app=express();
const hbs=require("hbs");


require("C:/mern/company_web/src/db/conn");
const Register=require("../models/entry")

const port =process.env.PORT || 8001;

const static_path=path.join(__dirname, "../../public");
const template_path=path.join(__dirname, "../../templates/views");
const partial_path=path.join(__dirname, "../../templates/partials");

app.use(express.urlencoded({extended:false}));
app.use(express.json());

app.use('/css',express.static(path.join(__dirname,"../../public")));
app.use('/img',express.static(path.join(__dirname,"../../src/images")))
app.use(express.static(static_path));
app.set("view engine",".hbs");
app.set("views",template_path);
hbs.registerPartials(partial_path);
const publicPath = path.resolve(__dirname, "public");
app.use(express.static(publicPath)); 

app.get("/",(req,res)=>{
    res.render("index")
});

app.post("/entry", async(req,res)=>{
    try{
        const RegisterIssue =new Register({
           firstName:req.body.firstname,
           lastName:req.body.lastname,
           Country:req.body.country,
           Issue:req.body.sub
         })
        //const userData=new Register(req.body);
         await RegisterIssue.save();
        res.status(201).render(index)
    }
    catch(error){
        res.status(400).send(error);}
})

app.listen(port,()=>{
    console.log("connection succesful");
})
