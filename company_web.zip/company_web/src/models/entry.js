const mongoose=require("mongoose");

const Issueschema=new mongoose.Schema({
    firstName:{
      type:String,
      required:true
    },
    lastName:{
      type:String,
      required:true
    },
    Country:{
     type:String,
     required:true
    },
    Issue:{
     type:String,
     required:true
    }

})
    const Register=new mongoose.model("Register",Issueschema);
    module.exports=Register;